1:"$Sreact.fragment"
2:I[7749,["/_next/static/chunks/0dbhjjzl8qfwv.js","/_next/static/chunks/0tcbhu-hiu-6o.js"],"default"]
3:I[97367,["/_next/static/chunks/0dbhjjzl8qfwv.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-gray-50","children":["$","$L2",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/0tcbhu-hiu-6o.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"mDopAfgRH1Ct976FcvaSC"}
5:null
