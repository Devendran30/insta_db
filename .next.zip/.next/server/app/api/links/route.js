var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/links/route.js")
R.c("server/chunks/[externals]__0wmg1nn._.js")
R.c("server/chunks/[root-of-the-server]__0_2vkc7._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_links_route_actions_0xd07jf.js")
R.m(77690)
module.exports=R.m(77690).exports
