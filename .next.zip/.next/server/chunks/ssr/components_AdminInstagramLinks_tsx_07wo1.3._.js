module.exports=[49105,a=>{"use strict";let b,c;var d,e=a.i(87924),f=a.i(72131);let g={data:""},h=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,i=/\/\*[^]*?\*\/|  +/g,j=/\n+/g,k=(a,b)=>{let c="",d="",e="";for(let f in a){let g=a[f];"@"==f[0]?"i"==f[1]?c=f+" "+g+";":d+="f"==f[1]?k(g,f):f+"{"+k(g,"k"==f[1]?"":b)+"}":"object"==typeof g?d+=k(g,b?b.replace(/([^,])+/g,a=>f.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,b=>/&/.test(b)?b.replace(/&/g,a):a?a+" "+b:b)):f):null!=g&&(f="-"==f[1]?f:f.replace(/[A-Z]/g,"-$&").toLowerCase(),e+=k.p?k.p(f,g):f+":"+g+";")}return c+(b&&e?b+"{"+e+"}":e)+d},l={},m=a=>{if("object"==typeof a){let b="";for(let c in a)b+=c+m(a[c]);return b}return a};function n(a){let b,c,d=this||{},e=a.call?a(d.p):a;return((a,b,c,d,e)=>{var f;let g=m(a),n=l[g]||(l[g]=(a=>{let b=0,c=11;for(;b<a.length;)c=101*c+a.charCodeAt(b++)>>>0;return"go"+c})(g));if(!l[n]){let b=g!==a?a:(a=>{let b,c,d=[{}];for(;b=h.exec(a.replace(i,""));)b[4]?d.shift():b[3]?(c=b[3].replace(j," ").trim(),d.unshift(d[0][c]=d[0][c]||{})):d[0][b[1]]=b[2].replace(j," ").trim();return d[0]})(a);l[n]=k(e?{["@keyframes "+n]:b}:b,c?"":"."+n)}let o=c&&l.g;return c&&(l.g=l[n]),f=l[n],o?b.data=b.data.replace(o,f):-1===b.data.indexOf(f)&&(b.data=d?f+b.data:b.data+f),n})(e.unshift?e.raw?(b=[].slice.call(arguments,1),c=d.p,e.reduce((a,d,e)=>{let f=b[e];if(f&&f.call){let a=f(c),b=a&&a.props&&a.props.className||/^go/.test(a)&&a;f=b?"."+b:a&&"object"==typeof a?a.props?"":k(a,""):!1===a?"":a}return a+d+(null==f?"":f)},"")):e.reduce((a,b)=>Object.assign(a,b&&b.call?b(d.p):b),{}):e,d.target||g,d.g,d.o,d.k)}n.bind({g:1});let o,p,q,r=n.bind({k:1});function s(a,b){let c=this||{};return function(){let d=arguments;function e(f,g){let h=Object.assign({},f),i=h.className||e.className;c.p=Object.assign({theme:p&&p()},h),c.o=/go\d/.test(i),h.className=n.apply(c,d)+(i?" "+i:""),b&&(h.ref=g);let j=a;return a[0]&&(j=h.as||a,delete h.as),q&&j[0]&&q(h),o(j,h)}return b?b(e):e}}var t=(a,b)=>"function"==typeof a?a(b):a,u=(b=0,()=>(++b).toString()),v="default",w=(a,b)=>{let{toastLimit:c}=a.settings;switch(b.type){case 0:return{...a,toasts:[b.toast,...a.toasts].slice(0,c)};case 1:return{...a,toasts:a.toasts.map(a=>a.id===b.toast.id?{...a,...b.toast}:a)};case 2:let{toast:d}=b;return w(a,{type:+!!a.toasts.find(a=>a.id===d.id),toast:d});case 3:let{toastId:e}=b;return{...a,toasts:a.toasts.map(a=>a.id===e||void 0===e?{...a,dismissed:!0,visible:!1}:a)};case 4:return void 0===b.toastId?{...a,toasts:[]}:{...a,toasts:a.toasts.filter(a=>a.id!==b.toastId)};case 5:return{...a,pausedAt:b.time};case 6:let f=b.time-(a.pausedAt||0);return{...a,pausedAt:void 0,toasts:a.toasts.map(a=>({...a,pauseDuration:a.pauseDuration+f}))}}},x=[],y={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},z={},A=(a,b=v)=>{z[b]=w(z[b]||y,a),x.forEach(([a,c])=>{a===b&&c(z[b])})},B=a=>Object.keys(z).forEach(b=>A(a,b)),C=(a=v)=>b=>{A(b,a)},D={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},E=a=>(b,c)=>{let d,e=((a,b="blank",c)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:b,ariaProps:{role:"status","aria-live":"polite"},message:a,pauseDuration:0,...c,id:(null==c?void 0:c.id)||u()}))(b,a,c);return C(e.toasterId||(d=e.id,Object.keys(z).find(a=>z[a].toasts.some(a=>a.id===d))))({type:2,toast:e}),e.id},F=(a,b)=>E("blank")(a,b);F.error=E("error"),F.success=E("success"),F.loading=E("loading"),F.custom=E("custom"),F.dismiss=(a,b)=>{let c={type:3,toastId:a};b?C(b)(c):B(c)},F.dismissAll=a=>F.dismiss(void 0,a),F.remove=(a,b)=>{let c={type:4,toastId:a};b?C(b)(c):B(c)},F.removeAll=a=>F.remove(void 0,a),F.promise=(a,b,c)=>{let d=F.loading(b.loading,{...c,...null==c?void 0:c.loading});return"function"==typeof a&&(a=a()),a.then(a=>{let e=b.success?t(b.success,a):void 0;return e?F.success(e,{id:d,...c,...null==c?void 0:c.success}):F.dismiss(d),a}).catch(a=>{let e=b.error?t(b.error,a):void 0;e?F.error(e,{id:d,...c,...null==c?void 0:c.error}):F.dismiss(d)}),a};var G=1e3,H=r`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,I=r`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,J=r`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,K=s("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${H} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${I} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${a=>a.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${J} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,L=r`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,M=s("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${a=>a.secondary||"#e0e0e0"};
  border-right-color: ${a=>a.primary||"#616161"};
  animation: ${L} 1s linear infinite;
`,N=r`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,O=r`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,P=s("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${N} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${O} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${a=>a.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,Q=s("div")`
  position: absolute;
`,R=s("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,S=r`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,T=s("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${S} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,U=({toast:a})=>{let{icon:b,type:c,iconTheme:d}=a;return void 0!==b?"string"==typeof b?f.createElement(T,null,b):b:"blank"===c?null:f.createElement(R,null,f.createElement(M,{...d}),"loading"!==c&&f.createElement(Q,null,"error"===c?f.createElement(K,{...d}):f.createElement(P,{...d})))},V=s("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,W=s("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,X=f.memo(({toast:a,position:b,style:d,children:e})=>{let g=a.height?((a,b)=>{let d=a.includes("top")?1:-1,[e,f]=c?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*d}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*d}%,-1px) scale(.6); opacity:0;}
`];return{animation:b?`${r(e)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${r(f)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(a.position||b||"top-center",a.visible):{opacity:0},h=f.createElement(U,{toast:a}),i=f.createElement(W,{...a.ariaProps},t(a.message,a));return f.createElement(V,{className:a.className,style:{...g,...d,...a.style}},"function"==typeof e?e({icon:h,message:i}):f.createElement(f.Fragment,null,h,i))});d=f.createElement,k.p=void 0,o=d,p=void 0,q=void 0;var Y=({id:a,className:b,style:c,onHeightUpdate:d,children:e})=>{let g=f.useCallback(b=>{if(b){let c=()=>{d(a,b.getBoundingClientRect().height)};c(),new MutationObserver(c).observe(b,{subtree:!0,childList:!0,characterData:!0})}},[a,d]);return f.createElement("div",{ref:g,className:b,style:c},e)},Z=n`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,$=({reverseOrder:a,position:b="top-center",toastOptions:d,gutter:e,children:g,toasterId:h,containerStyle:i,containerClassName:j})=>{let{toasts:k,handlers:l}=((a,b="default")=>{let{toasts:c,pausedAt:d}=((a={},b=v)=>{let[c,d]=(0,f.useState)(z[b]||y),e=(0,f.useRef)(z[b]);(0,f.useEffect)(()=>(e.current!==z[b]&&d(z[b]),x.push([b,d]),()=>{let a=x.findIndex(([a])=>a===b);a>-1&&x.splice(a,1)}),[b]);let g=c.toasts.map(b=>{var c,d,e;return{...a,...a[b.type],...b,removeDelay:b.removeDelay||(null==(c=a[b.type])?void 0:c.removeDelay)||(null==a?void 0:a.removeDelay),duration:b.duration||(null==(d=a[b.type])?void 0:d.duration)||(null==a?void 0:a.duration)||D[b.type],style:{...a.style,...null==(e=a[b.type])?void 0:e.style,...b.style}}});return{...c,toasts:g}})(a,b),e=(0,f.useRef)(new Map).current,g=(0,f.useCallback)((a,b=G)=>{if(e.has(a))return;let c=setTimeout(()=>{e.delete(a),h({type:4,toastId:a})},b);e.set(a,c)},[]);(0,f.useEffect)(()=>{if(d)return;let a=Date.now(),e=c.map(c=>{if(c.duration===1/0)return;let d=(c.duration||0)+c.pauseDuration-(a-c.createdAt);if(d<0){c.visible&&F.dismiss(c.id);return}return setTimeout(()=>F.dismiss(c.id,b),d)});return()=>{e.forEach(a=>a&&clearTimeout(a))}},[c,d,b]);let h=(0,f.useCallback)(C(b),[b]),i=(0,f.useCallback)(()=>{h({type:5,time:Date.now()})},[h]),j=(0,f.useCallback)((a,b)=>{h({type:1,toast:{id:a,height:b}})},[h]),k=(0,f.useCallback)(()=>{d&&h({type:6,time:Date.now()})},[d,h]),l=(0,f.useCallback)((a,b)=>{let{reverseOrder:d=!1,gutter:e=8,defaultPosition:f}=b||{},g=c.filter(b=>(b.position||f)===(a.position||f)&&b.height),h=g.findIndex(b=>b.id===a.id),i=g.filter((a,b)=>b<h&&a.visible).length;return g.filter(a=>a.visible).slice(...d?[i+1]:[0,i]).reduce((a,b)=>a+(b.height||0)+e,0)},[c]);return(0,f.useEffect)(()=>{c.forEach(a=>{if(a.dismissed)g(a.id,a.removeDelay);else{let b=e.get(a.id);b&&(clearTimeout(b),e.delete(a.id))}})},[c,g]),{toasts:c,handlers:{updateHeight:j,startPause:i,endPause:k,calculateOffset:l}}})(d,h);return f.createElement("div",{"data-rht-toaster":h||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...i},className:j,onMouseEnter:l.startPause,onMouseLeave:l.endPause},k.map(d=>{let h,i,j=d.position||b,k=l.calculateOffset(d,{reverseOrder:a,gutter:e,defaultPosition:b}),m=(h=j.includes("top"),i=j.includes("center")?{justifyContent:"center"}:j.includes("right")?{justifyContent:"flex-end"}:{},{left:0,right:0,display:"flex",position:"absolute",transition:c?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${k*(h?1:-1)}px)`,...h?{top:0}:{bottom:0},...i});return f.createElement(Y,{id:d.id,key:d.id,onHeightUpdate:l.updateHeight,className:d.visible?Z:"",style:m},"custom"===d.type?t(d.message,d):g?g(d):f.createElement(X,{toast:d,position:j}))}))},_={color:void 0,size:void 0,className:void 0,style:void 0,attr:void 0},aa=f.default.createContext&&f.default.createContext(_),ab=["attr","size","title"];function ac(){return(ac=Object.assign.bind()).apply(null,arguments)}function ad(a,b){var c=Object.keys(a);if(Object.getOwnPropertySymbols){var d=Object.getOwnPropertySymbols(a);b&&(d=d.filter(function(b){return Object.getOwnPropertyDescriptor(a,b).enumerable})),c.push.apply(c,d)}return c}function ae(a){for(var b=1;b<arguments.length;b++){var c=null!=arguments[b]?arguments[b]:{};b%2?ad(Object(c),!0).forEach(function(b){var d,e,f;d=a,e=b,f=c[b],(e=function(a){var b=function(a,b){if("object"!=typeof a||!a)return a;var c=a[Symbol.toPrimitive];if(void 0!==c){var d=c.call(a,b||"default");if("object"!=typeof d)return d;throw TypeError("@@toPrimitive must return a primitive value.")}return("string"===b?String:Number)(a)}(a,"string");return"symbol"==typeof b?b:b+""}(e))in d?Object.defineProperty(d,e,{value:f,enumerable:!0,configurable:!0,writable:!0}):d[e]=f}):Object.getOwnPropertyDescriptors?Object.defineProperties(a,Object.getOwnPropertyDescriptors(c)):ad(Object(c)).forEach(function(b){Object.defineProperty(a,b,Object.getOwnPropertyDescriptor(c,b))})}return a}function af(a){var b=b=>{var c,{attr:d,size:e,title:g}=a,h=function(a,b){if(null==a)return{};var c,d,e=function(a,b){if(null==a)return{};var c={};for(var d in a)if(({}).hasOwnProperty.call(a,d)){if(-1!==b.indexOf(d))continue;c[d]=a[d]}return c}(a,b);if(Object.getOwnPropertySymbols){var f=Object.getOwnPropertySymbols(a);for(d=0;d<f.length;d++)c=f[d],-1===b.indexOf(c)&&({}).propertyIsEnumerable.call(a,c)&&(e[c]=a[c])}return e}(a,ab),i=e||b.size||"1em";return b.className&&(c=b.className),a.className&&(c=(c?c+" ":"")+a.className),f.default.createElement("svg",ac({stroke:"currentColor",fill:"currentColor",strokeWidth:"0"},b.attr,d,h,{className:c,style:ae(ae({color:a.color||b.color},b.style),a.style),height:i,width:i,xmlns:"http://www.w3.org/2000/svg"}),g&&f.default.createElement("title",null,g),a.children)};return void 0!==aa?f.default.createElement(aa.Consumer,null,a=>b(a)):b(_)}function ag(a){var b;return(b={tag:"svg",attr:{viewBox:"0 0 448 512"},child:[{tag:"path",attr:{d:"M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"},child:[]}]},a=>f.default.createElement(af,ac({attr:ae({},b.attr)},a),function a(b){return b&&b.map((b,c)=>f.default.createElement(b.tag,ae({key:c},b.attr),a(b.child)))}(b.child)))(a)}let ah=(...a)=>a.filter((a,b,c)=>!!a&&""!==a.trim()&&c.indexOf(a)===b).join(" ").trim(),ai=a=>{let b=a.replace(/^([A-Z])|[\s-_]+(\w)/g,(a,b,c)=>c?c.toUpperCase():b.toLowerCase());return b.charAt(0).toUpperCase()+b.slice(1)};var aj={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let ak=(0,f.createContext)({}),al=(0,f.forwardRef)(({color:a,size:b,strokeWidth:c,absoluteStrokeWidth:d,className:e="",children:g,iconNode:h,...i},j)=>{let{size:k=24,strokeWidth:l=2,absoluteStrokeWidth:m=!1,color:n="currentColor",className:o=""}=(0,f.useContext)(ak)??{},p=d??m?24*Number(c??l)/Number(b??k):c??l;return(0,f.createElement)("svg",{ref:j,...aj,width:b??k??aj.width,height:b??k??aj.height,stroke:a??n,strokeWidth:p,className:ah("lucide",o,e),...!g&&!(a=>{for(let b in a)if(b.startsWith("aria-")||"role"===b||"title"===b)return!0;return!1})(i)&&{"aria-hidden":"true"},...i},[...h.map(([a,b])=>(0,f.createElement)(a,b)),...Array.isArray(g)?g:[g]])}),am=(a,b)=>{let c=(0,f.forwardRef)(({className:c,...d},e)=>(0,f.createElement)(al,{ref:e,iconNode:b,className:ah(`lucide-${ai(a).replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,`lucide-${a}`,c),...d}));return c.displayName=ai(a),c},an=am("trash-2",[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]]),ao=am("pencil",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]]),ap=am("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);a.s(["default",0,function(){let[a,b]=(0,f.useState)([]),[c,d]=(0,f.useState)(!1),[g,h]=(0,f.useState)(!1),[i,j]=(0,f.useState)(""),[k,l]=(0,f.useState)(!0),[m,n]=(0,f.useState)(null);(0,f.useEffect)(()=>{o()},[]),(0,f.useEffect)(()=>{if(!a.length)return;let b=()=>{window.instgrm&&window.instgrm.Embeds.process()};if(window.instgrm)b();else{let a=document.createElement("script");a.src="https://www.instagram.com/embed.js",a.async=!0,a.onload=b,document.body.appendChild(a)}},[a]);let o=async()=>{d(!0);try{let a=await fetch("/api/links"),c=await a.json();b(Array.isArray(c)?c:[])}catch{F.error("Failed to fetch links")}d(!1)},p=/^https?:\/\/(www\.)?instagram\.com\/(p|reel|tv)\/[A-Za-z0-9_\-]+\/?/,q=async()=>{if(!i)return F.error("URL required");if(!p.test(i))return F.error("Invalid Instagram URL");try{null!==m?(await fetch(`/api/links/${m}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:i,published:k})}),F.success("Updated")):(await fetch("/api/links",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({url:i,published:k})}),F.success("Added")),s(),o()}catch{F.error("Error occurred")}},r=async a=>{if(confirm("Are you sure?"))try{await fetch(`/api/links/${a}`,{method:"DELETE"}),F.success("Deleted"),o()}catch{F.error("Delete failed")}},s=()=>{n(null),j(""),l(!0),h(!1)};return(0,e.jsxs)("div",{className:"p-6 md:p-10 min-h-screen bg-gray-50 space-y-8 text-black",children:[(0,e.jsx)($,{position:"top-right"}),(0,e.jsxs)("div",{className:"flex justify-between items-center",children:[(0,e.jsxs)("h1",{className:"text-2xl font-bold flex items-center gap-2 text-orange-600",children:[(0,e.jsx)(ag,{size:28}),"Instagram Feed"]}),(0,e.jsxs)("button",{onClick:()=>h(!0),className:"flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition",children:[(0,e.jsx)(ap,{size:16}),"Add Link"]})]}),c&&(0,e.jsx)("p",{className:"text-gray-500",children:"Loading..."}),(0,e.jsx)("div",{className:"flex gap-6 overflow-x-auto pb-4 snap-x",children:a.map(a=>(0,e.jsxs)("div",{className:"min-w-[350px] bg-white rounded-xl shadow-md p-2 snap-center border border-gray-100",children:[(0,e.jsx)("blockquote",{className:"instagram-media","data-instgrm-permalink":a.url,"data-instgrm-version":"14"}),(0,e.jsxs)("div",{className:"flex justify-between mt-2 px-2 pb-2",children:[(0,e.jsx)("button",{onClick:()=>{n(a.id),j(a.url),l(!!a.published),h(!0)},className:"text-gray-600 hover:text-blue-500",children:(0,e.jsx)(ao,{size:18})}),(0,e.jsx)("button",{onClick:()=>r(a.id),className:"text-red-500 hover:text-red-700",children:(0,e.jsx)(an,{size:18})})]})]},a.id))}),g&&(0,e.jsx)("div",{className:"fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm",children:(0,e.jsxs)("div",{className:"bg-white p-6 rounded-xl w-96 space-y-4 shadow-2xl border border-gray-200",children:[(0,e.jsx)("h2",{className:"font-bold text-xl text-black border-b pb-2",children:m?"Edit Instagram Post":"Add New Post"}),(0,e.jsxs)("div",{className:"space-y-1",children:[(0,e.jsx)("label",{className:"text-xs font-semibold text-gray-500 uppercase",children:"Post URL"}),(0,e.jsx)("input",{type:"text",value:i,onChange:a=>j(a.target.value),placeholder:"https://instagram.com/p/...",className:"w-full border border-gray-300 p-2 rounded-lg text-black focus:ring-2 focus:ring-orange-500 outline-none"})]}),(0,e.jsxs)("div",{className:"flex items-center justify-between bg-gray-50 p-2 rounded-lg",children:[(0,e.jsx)("span",{className:"text-sm text-gray-600",children:"Status"}),(0,e.jsx)("button",{onClick:()=>l(!k),className:`px-4 py-1 rounded-full text-xs font-bold transition ${k?"bg-green-100 text-green-700":"bg-gray-200 text-gray-600"}`,children:k?"PUBLIC":"HIDDEN"})]}),(0,e.jsxs)("div",{className:"flex gap-3 pt-2",children:[(0,e.jsx)("button",{onClick:q,className:"flex-1 bg-orange-600 hover:bg-orange-700 text-white font-bold py-2 rounded-lg transition",children:m?"Update Post":"Save Post"}),(0,e.jsx)("button",{onClick:s,className:"flex-1 border border-gray-300 hover:bg-gray-50 text-gray-700 py-2 rounded-lg transition",children:"Cancel"})]})]})})]})}],49105)}];

//# sourceMappingURL=components_AdminInstagramLinks_tsx_07wo1.3._.js.map