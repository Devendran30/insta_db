module.exports=[13637,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_links_route_actions_0xd07jf.js.map